return {
    love = {},
    _common = {}
}