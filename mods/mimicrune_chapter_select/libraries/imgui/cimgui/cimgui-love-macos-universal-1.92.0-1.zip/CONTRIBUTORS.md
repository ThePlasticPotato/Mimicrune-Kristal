# Additional contributors

- [zombrodo](https://codeberg.org/zombrodo)
- [Jasper_Krocke](https://codeberg.org/Jasper_Krocke)
